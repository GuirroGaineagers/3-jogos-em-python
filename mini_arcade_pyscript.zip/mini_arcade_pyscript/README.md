# Mini Arcade — Python no navegador

Projeto com três jogos escritos em **Python**, executados no navegador através do [PyScript](https://pyscript.net/). Não utiliza JavaScript escrito pelo projeto nem precisa de instalar Python ou Flask.

## Ficheiros

- `index.html` — página principal. Inclui o código Python PyScript embutido para permitir abrir o HTML diretamente.
- `jogos.py` — cópia organizada da lógica Python dos jogos, para consulta e edição no VS Code. Como o HTML foi preparado para abrir diretamente por duplo clique, a versão executada está embutida no `index.html`.
- `estilos.css` — design responsivo, cores, animações e apresentação dos jogos.
- `README.md` — estas instruções.

## Como abrir

1. Extrai o ZIP para uma pasta.
2. Mantém os ficheiros juntos na mesma pasta.
3. Faz duplo clique em `index.html`.
4. Abre com Chrome, Edge, Firefox ou Safari atualizado.
5. Mantém a ligação à Internet ativa na primeira abertura: o PyScript e o interpretador Python são carregados a partir dos servidores oficiais. Não é necessário instalar Python.

> **Importante:** o HTML executa Python através do PyScript. Para permitir a abertura direta com duplo clique, o código executável está embutido no `index.html`. O ficheiro `jogos.py` contém a mesma lógica em formato separado para leitura/edição. Se alterares os jogos no `jogos.py`, tens de copiar essas alterações para o bloco `<script type="py">` do HTML.

## Jogos incluídos

### 1. 2048
- Grelha 4×4 e fusão correta de blocos iguais.
- Controlos por setas do teclado e botões no ecrã.
- Pontuação, novo jogo e deteção de fim de jogo.

### 2. Adivinha o Número
- Três dificuldades: fácil (1–20), médio (1–50) e difícil (1–100).
- Número aleatório, limite de tentativas e pistas de maior/menor.
- Pontuação automática quando o jogador acerta.

### 3. Adivinha a Idade
- Perguntas Sim/Não com pesquisa binária entre 1 e 120 anos.
- Encontra a resposta em, no máximo, 7 perguntas.
- Pontuação quando acerta.

## Best Scores

A tabela guarda até 10 resultados no armazenamento local do navegador (`localStorage`). Os recordes ficam no dispositivo/navegador onde foram obtidos; não são partilhados automaticamente entre amigos ou computadores. O comportamento do armazenamento em páginas `file://` pode variar consoante o navegador e as respetivas definições de privacidade.

## Partilhar com amigos

Podes enviar a pasta ZIP aos teus amigos para extraírem e abrirem `index.html`. Para teres **um link público** que abre o jogo sem descarregar a pasta, tens de alojar os ficheiros num serviço de alojamento estático. O PyScript executa Python no navegador de cada visitante.

## Nota sobre desempenho

O jogo não usa bibliotecas Python externas. O primeiro carregamento pode demorar um pouco mais porque o navegador tem de descarregar o motor Python/WebAssembly do PyScript. Depois de carregado, a lógica dos jogos é leve e corre localmente no navegador.
