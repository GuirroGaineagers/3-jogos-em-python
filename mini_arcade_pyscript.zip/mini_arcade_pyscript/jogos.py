"""Mini Arcade — lógica dos três jogos em Python (PyScript)."""
from pyscript import when, window, document
import random
import json
import html

# Estado dos jogos
board = []
score_2048 = 0
number_secret = None
number_attempts = 0
number_limit = 0
number_max = 0
age_low = 1
age_high = 120
age_questions = 0

STORAGE_KEY = "mini-arcade-best-scores-v1"


def el(identifier):
    return document.getElementById(identifier)


def notify(message, kind="info"):
    node = el("notice")
    node.textContent = message
    node.className = "notice " + kind


def load_scores():
    try:
        raw = window.localStorage.getItem(STORAGE_KEY)
        return json.loads(raw) if raw else []
    except Exception:
        return []


def save_score(game, player, points):
    scores = load_scores()
    scores.append({"game": game, "player": player[:18] or "Jogador", "score": int(points)})
    scores.sort(key=lambda item: item.get("score", 0), reverse=True)
    scores = scores[:10]
    try:
        window.localStorage.setItem(STORAGE_KEY, json.dumps(scores))
    except Exception:
        notify("Não foi possível guardar os recordes neste navegador.", "warning")
    render_scores()


def render_scores():
    scores = load_scores()
    body = el("scores-body")
    if not scores:
        body.innerHTML = '<tr><td colspan="4" class="empty">Ainda não existem recordes. Sê o primeiro!</td></tr>'
        return
    rows = []
    for index, item in enumerate(scores, 1):
        rows.append(
            "<tr><td>" + str(index) + "</td><td>" + html.escape(str(item.get("player", "Jogador"))) +
            "</td><td>" + html.escape(str(item.get("game", "Jogo"))) +
            "</td><td><strong>" + str(int(item.get("score", 0))) + "</strong></td></tr>"
        )
    body.innerHTML = "".join(rows)


def show_game(game_id):
    for name in ("2048", "number", "age"):
        el("panel-" + name).classList.toggle("active", name == game_id)
        el("tab-" + name).classList.toggle("active", name == game_id)


@when("click", "#tab-2048")
def tab_2048(event):
    show_game("2048")


@when("click", "#tab-number")
def tab_number(event):
    show_game("number")


@when("click", "#tab-age")
def tab_age(event):
    show_game("age")


def empty_cells():
    return [(r, c) for r in range(4) for c in range(4) if board[r][c] == 0]


def add_tile():
    empty = empty_cells()
    if empty:
        r, c = random.choice(empty)
        board[r][c] = 4 if random.random() < 0.1 else 2


def render_2048():
    cells = []
    for row in board:
        for value in row:
            label = str(value) if value else ""
            css = "tile tile-" + str(value) if value else "tile tile-0"
            cells.append('<div class="' + css + '" aria-label="' + (label or "vazio") + '"><span>' + label + '</span></div>')
    el("board").innerHTML = "".join(cells)
    el("score-2048").textContent = str(score_2048)
    if not empty_cells() and not any(can_merge()):
        notify("Fim do jogo! Já não há movimentos possíveis. Inicia um novo jogo.", "warning")


def can_merge():
    for r in range(4):
        for c in range(4):
            value = board[r][c]
            if value and ((r < 3 and board[r + 1][c] == value) or (c < 3 and board[r][c + 1] == value)):
                return [True]
    return []


def compress_merge(line):
    global score_2048
    values = [value for value in line if value]
    result = []
    index = 0
    while index < len(values):
        if index + 1 < len(values) and values[index] == values[index + 1]:
            merged = values[index] * 2
            result.append(merged)
            score_2048 += merged
            index += 2
        else:
            result.append(values[index])
            index += 1
    return result + [0] * (4 - len(result))


def move(direction):
    global board
    old = [row[:] for row in board]
    for i in range(4):
        if direction == "left":
            line = board[i][:]
            merged = compress_merge(line)
            board[i] = merged
        elif direction == "right":
            board[i] = list(reversed(compress_merge(list(reversed(board[i])))))
        elif direction == "up":
            line = [board[r][i] for r in range(4)]
            merged = compress_merge(line)
            for r in range(4):
                board[r][i] = merged[r]
        elif direction == "down":
            line = [board[r][i] for r in range(3, -1, -1)]
            merged = list(reversed(compress_merge(line)))
            for r in range(4):
                board[r][i] = merged[r]
    if board != old:
        add_tile()
        render_2048()


def new_2048():
    global board, score_2048
    board = [[0] * 4 for _ in range(4)]
    score_2048 = 0
    add_tile()
    add_tile()
    render_2048()
    notify("Novo jogo iniciado. Junta os números até chegares a 2048!", "success")


@when("click", "#new-2048")
def restart_2048(event):
    new_2048()


@when("click", "#move-up")
def move_up(event):
    move("up")


@when("click", "#move-down")
def move_down(event):
    move("down")


@when("click", "#move-left")
def move_left(event):
    move("left")


@when("click", "#move-right")
def move_right(event):
    move("right")


@when("click", "#finish-2048")
def finish_2048(event):
    save_score("2048", el("player-name").value.strip() or "Jogador", score_2048)
    notify("Pontuação guardada na tabela de recordes!", "success")


@when("change", "#difficulty")
def change_difficulty(event):
    global number_max, number_limit
    settings = {"easy": (20, 7), "medium": (50, 6), "hard": (100, 7)}
    new_number_game()


def new_number_game():
    global number_secret, number_attempts, number_max, number_limit
    settings = {"easy": (20, 7), "medium": (50, 6), "hard": (100, 7)}
    number_max, number_limit = settings.get(el("difficulty").value, (50, 6))
    number_secret = random.randint(1, number_max)
    number_attempts = 0
    el("guess-input").disabled = False
    el("guess-button").disabled = False
    el("guess-input").value = ""
    el("guess-input").max = str(number_max)
    el("attempts-left").textContent = str(number_limit)
    el("guess-feedback").textContent = "Escolhi um número. Consegues descobri-lo?"
    el("guess-feedback").className = "game-feedback"
    el("difficulty-info").textContent = "Intervalo: 1–" + str(number_max) + " · Tentativas: " + str(number_limit)


@when("click", "#new-number")
def restart_number(event):
    new_number_game()


@when("click", "#guess-button")
def make_guess(event):
    global number_attempts
    if number_secret is None or el("guess-input").disabled:
        return
    raw = el("guess-input").value.strip()
    if not raw:
        el("guess-feedback").textContent = "Introduz primeiro um número."
        return
    guess = int(raw)
    if guess < 1 or guess > number_max:
        el("guess-feedback").textContent = "Escolhe um número entre 1 e " + str(number_max) + "."
        return
    number_attempts += 1
    remaining = number_limit - number_attempts
    el("attempts-left").textContent = str(max(0, remaining))
    if guess == number_secret:
        points = max(10, (number_limit - number_attempts + 1) * 10)
        el("guess-feedback").textContent = "Excelente! Acertaste em " + str(number_attempts) + " tentativa(s). +" + str(points) + " pontos."
        el("guess-feedback").className = "game-feedback success-text"
        el("guess-input").disabled = True
        el("guess-button").disabled = True
        save_score("Adivinha o Número", el("player-name").value.strip() or "Jogador", points)
    elif remaining <= 0:
        el("guess-feedback").textContent = "As tentativas terminaram. O número era " + str(number_secret) + "."
        el("guess-feedback").className = "game-feedback warning-text"
        el("guess-input").disabled = True
        el("guess-button").disabled = True
    else:
        hint = "É maior!" if guess < number_secret else "É menor!"
        el("guess-feedback").textContent = hint + " Ainda tens " + str(remaining) + " tentativa(s)."
        el("guess-feedback").className = "game-feedback"
    el("guess-input").value = ""
    el("guess-input").focus()


@when("keydown", "#guess-input")
def guess_enter(event):
    if event.key == "Enter":
        make_guess(event)


def reset_age_game():
    global age_low, age_high, age_questions
    age_low, age_high, age_questions = 1, 120, 0
    render_age_question()


def render_age_question():
    if age_low == age_high:
        el("age-question").textContent = "A tua idade é " + str(age_low) + " anos?"
        el("age-subtitle").textContent = "Cheguei à minha previsão!"
        el("age-actions").classList.add("confirm-mode")
        el("age-progress").textContent = str(age_questions) + " perguntas"
        el("age-yes").textContent = "Sim, acertaste!"
        el("age-no").textContent = "Não, tenta outra vez"
        return
    middle = (age_low + age_high) // 2
    el("age-question").textContent = "A tua idade é superior a " + str(middle) + " anos?"
    el("age-subtitle").textContent = "Responde com sinceridade para eu tentar adivinhar."
    el("age-actions").classList.remove("confirm-mode")
    el("age-yes").textContent = "Sim"
    el("age-no").textContent = "Não"
    el("age-progress").textContent = str(age_questions) + " perguntas · intervalo " + str(age_low) + "–" + str(age_high)


def age_answer(is_yes):
    global age_low, age_high, age_questions
    if age_low == age_high:
        if is_yes:
            points = max(10, 120 - age_questions * 10)
            el("age-question").textContent = "Acertei! A tua idade é " + str(age_low) + " anos. 🎉"
            el("age-subtitle").textContent = "Consegui descobrir em " + str(age_questions) + " perguntas."
            el("age-actions").classList.add("hidden")
            save_score("Adivinha a Idade", el("player-name").value.strip() or "Jogador", points)
            notify("Idade adivinhada! Recorde guardado.", "success")
        else:
            el("age-question").textContent = "Ups! Não consegui adivinhar."
            el("age-subtitle").textContent = "Podes tentar novamente."
            el("age-actions").classList.add("hidden")
        return
    middle = (age_low + age_high) // 2
    if is_yes:
        age_low = middle + 1
    else:
        age_high = middle
    age_questions += 1
    render_age_question()


@when("click", "#age-yes")
def age_yes(event):
    age_answer(True)


@when("click", "#age-no")
def age_no(event):
    age_answer(False)


@when("click", "#new-age")
def restart_age(event):
    el("age-actions").classList.remove("hidden")
    reset_age_game()


@when("click", "#clear-scores")
def clear_scores(event):
    try:
        window.localStorage.removeItem(STORAGE_KEY)
    except Exception:
        pass
    render_scores()
    notify("Tabela de recordes limpa neste navegador.", "success")


# Controlos de teclado do 2048. Os inputs mantêm o comportamento normal.
def keyboard_handler(event):
    target = event.target
    tag = str(getattr(target, "tagName", "")).lower()
    if tag in ("input", "textarea", "select"):
        return
    keys = {"ArrowUp": "up", "ArrowDown": "down", "ArrowLeft": "left", "ArrowRight": "right"}
    direction = keys.get(event.key)
    if direction and el("panel-2048").classList.contains("active"):
        event.preventDefault()
        move(direction)


document.addEventListener("keydown", keyboard_handler)

# Inicialização
new_2048()
new_number_game()
reset_age_game()
render_scores()
